# Deployment Instructions — Steps You Need To Do Yourself

Everything in this package is ready to upload. Four of the five deliverables
(SRS, Notebook, app code, README) are done. The last three steps below need
**your own GitHub, Streamlit, and LinkedIn accounts** — I can't create
accounts or post on your behalf, but here's exactly what to click.

## Files in this package
```
Assignment7_SyedIsrarAli.ipynb   → Deliverable 2 (Notebook) — ready to submit as-is
SRS_Document.docx                → Deliverable 1 (SRS) — ready to submit as-is
app.py                           → Streamlit web app
model.pkl, scaler.pkl,
feature_names.pkl                → Saved trained model (needed by app.py)
requirements.txt                 → Dependencies for GitHub + Streamlit Cloud
README.md                        → GitHub repo description
```

## Step 1 — Create the GitHub Repository (Deliverable 3)
1. Go to https://github.com and log in (create a free account if you don't have one).
2. Click **New repository**. Name it something like `breast-cancer-diagnosis-predictor`.
3. Set it to **Public** (required — the assignment needs a public link).
4. Don't initialize with a README (you already have one).
5. On your computer, in the folder containing all these files, run:
   ```bash
   git init
   git add .
   git commit -m "Capstone project: Breast Cancer Diagnosis Predictor"
   git branch -M main
   git remote add origin https://github.com/<your-username>/breast-cancer-diagnosis-predictor.git
   git push -u origin main
   ```
6. Copy the repository URL — that's Deliverable 3.

## Step 2 — Deploy on Streamlit Community Cloud (Deliverable 5)
1. Go to https://share.streamlit.io and log in with your GitHub account.
2. Click **New app**.
3. Select the repository you just pushed, branch `main`, and main file path `app.py`.
4. Click **Deploy**. It will install `requirements.txt` automatically and launch.
5. Wait 1–3 minutes for the build. You'll get a public URL like:
   `https://<your-app-name>.streamlit.app`
6. Test it: pick an example patient and click Predict to confirm it works live.
7. Copy that URL — that's Deliverable 5.

## Step 3 — Write the LinkedIn Post (Deliverable 4)
1. Take a screenshot or short screen recording of your live Streamlit app in action.
2. Go to LinkedIn → Start a post → attach the screenshot/video.
3. Suggested post text (edit to sound like you):

   > 🚀 Just completed my AI/ML capstone project: a Breast Cancer Diagnosis
   > Predictor! Built and evaluated Logistic Regression & Random Forest
   > models (98%+ accuracy) on the Breast Cancer Wisconsin dataset, then
   > deployed it as a live Streamlit web app so anyone can try it.
   >
   > This was part of my Artificial Intelligence (ML & DL) training under
   > NAVTTC's Prime Minister's Hunarmand Pakistan Program.
   >
   > 🔗 Live demo: [your Streamlit link]
   > 💻 Code: [your GitHub link]
   >
   > #MachineLearning #DeepLearning #AI #DataScience #Python #Streamlit
   > #NAVTTC #HunarmandPakistan #Portfolio

4. Set the post visibility to **Public**, publish it, then copy the post's URL — that's Deliverable 4.

## Step 4 — Final Submission
Submit a single document/notebook cell listing all five links:
1. SRS Document — attach `SRS_Document.docx` directly
2. Jupyter Notebook — attach `Assignment7_SyedIsrarAli.ipynb` directly
3. GitHub Repository Link — from Step 1
4. LinkedIn Post Link — from Step 3
5. Streamlit App Link — from Step 2

Double-check every link opens in a private/incognito browser window before
submitting, to confirm it's genuinely public.
